#include <stdio.h>
#include <windows.h>

extern "C" __declspec(dllexport) WORD getScreenWidth()
{
	return GetSystemMetrics(SM_CXSCREEN);
}

extern "C" __declspec(dllexport) void CPU_ID(int regs[1], int func)
{
	int ieax, iebx, iecx, iedx;
	_asm
	{
		mov eax, func
		cpuid
		mov ieax, eax
		mov iebx, ebx
		mov iecx, ecx
		mov iedx, edx
	}
	regs[0] = ieax;
	regs[1] = iebx;
	regs[2] = iecx;
	regs[3] = iedx;
}
